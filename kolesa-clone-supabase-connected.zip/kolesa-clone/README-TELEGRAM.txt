АвтоМаркет — Telegram Mini App
================================

1) КНОПКИ ПОЧИНЕНЫ
В прошлой версии из-за ошибки JS ничего не нажималось. Сейчас исправлено.

2) ОНЛАЙН + TELEGRAM MINI APP

Приложению нужен HTTPS-адрес. Бесплатно:

Вариант A — Netlify Drop (самый простой)
- Зайди на https://app.netlify.com/drop
- Перетащи папку kolesa-clone или файл index.html
- Получишь ссылку вида https://xxxx.netlify.app

Вариант B — GitHub Pages
- Создай репозиторий, залей index.html
- Settings → Pages → включи Pages
- Ссылка: https://USERNAME.github.io/REPO/

Вариант C — Cloudflare Pages
- https://pages.cloudflare.com → загрузить папку

3) ПОДКЛЮЧЕНИЕ К TELEGRAM

1. Открой @BotFather в Telegram
2. /newbot — создай бота (или возьми существующего)
3. /newapp — создай Mini App
   - выбери бота
   - название: АвтоМаркет
   - описание: любое
   - фото (опционально)
   - URL: твоя ссылка с Netlify/GitHub (https://....)
4. /setmenubutton — привяжи кнопку меню к Mini App
   или отправь ссылку: https://t.me/BOT_USERNAME/APP_SHORT_NAME

Готово — Mini App откроется внутри Telegram.

4) ЛОКАЛЬНО
Можно по-прежнему открыть index.html в Safari/Chrome.
В Telegram-браузере подтянется оформление Telegram.

========================================
SUPABASE (сохранение пользователей TG)
========================================

1. Создай проект на https://supabase.com
2. В SQL Editor выполни:

create table users (
  telegram_id bigint primary key,
  username text,
  first_name text,
  last_name text,
  language_code text,
  created_at timestamptz default now()
);

-- Разреши запись для anon key (для демо):
alter table users enable row level security;
create policy "allow upsert" on users for all using (true) with check (true);

3. Project Settings → API → скопируй URL и anon key
4. В index.html замени:
   const SUPABASE_URL = 'https://xxxxx.supabase.co';
   const SUPABASE_KEY = 'eyJ...';

5. Залей index.html на Netlify и укажи URL в BotFather Mini App
